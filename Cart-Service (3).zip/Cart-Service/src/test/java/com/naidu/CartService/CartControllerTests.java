package com.naidu.CartService;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.naidu.CartService.controller.CartController;
import com.naidu.CartService.entity.Cart;
import com.naidu.CartService.repository.CartRepository;
import com.naidu.CartService.service.CartService;
import com.naidu.CartService.service.CartServiceImpl;

class CartControllerTests {

	@Mock
	private CartService cartService;

	@Mock
	private CartRepository cartRepository;

	@Mock
	private CartServiceImpl cartServiceImpl;

	@InjectMocks
	private CartController cartController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void decreaseItem_ShouldReturnCart() {
		// Arrange
		int productId = 1;
		int cartId = 1;
		Cart cart = new Cart();
		when(cartService.decreaseItem(productId, cartId)).thenReturn(cart);

		// Act
		Cart result = cartController.decreaseItem(productId, cartId);

		// Assert
		assertNotNull(result);
		// Add more assertions if needed
	}

}
