package com.OnlineShoppingCart.Entity;

public interface Role {
	
	static final String customer="customer";
	static final String deliveryAgent="delivery Agent";

}