package com.OnlineShopping.Exceptions;

public class ProfileNotFoundException extends RuntimeException{
	public ProfileNotFoundException(String msg) {
		super(msg);
	}

}
