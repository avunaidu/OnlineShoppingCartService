package com.OnlineShoppingCart;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;

import com.OnlineShopping.ServiceImpl.ProfileServiceImpl;
import com.OnlineShoppingCart.Controller.ProfileController;
import com.OnlineShoppingCart.Entity.Address;
import com.OnlineShoppingCart.Entity.UserProfile;
import com.OnlineShoppingCart.Repository.ProfileRepository;

@SpringBootTest(classes= {UserProfile.class})
 class ProfileServiceImplTest {
	@MockBean
	ProfileRepository profileRepo;
	@Mock
	ProfileServiceImpl profileserimpl;
	@InjectMocks
	ProfileController profilecontroller;
List<UserProfile> userprofiles;
UserProfile userprofile;
@Test
public void  getAllProfiles() {
	userprofiles = new ArrayList<>();
	userprofiles.add(new UserProfile(100, "mounika", "mounikaalla141@gmail.com", 9182235379L, LocalDate.of(2001,03,06), "male", new Address()));
	

	when(profileserimpl.getAllProfiles()).thenReturn(userprofiles);
	ResponseEntity<List<UserProfile>> allprofiles = profilecontroller.getAllProfiles();
	assertEquals(1, allprofiles.getBody().size());
}
@Test
public void getByProfileId() {

	userprofile = new UserProfile(23, "mounika",  "mounikaalla141@gmail.com", 9182235379L, LocalDate.of(2001,03,06), "male", new Address());
	int profileId = 23;

	when(profileserimpl.getByProfileId(profileId)).thenReturn(userprofile);
	ResponseEntity<UserProfile> profileid = profilecontroller.getByProfileId(profileId);
	assertEquals(profileId, profileid.getBody().getProfileId());
}
@Test
public void addNewCustomerProfile() {

	userprofile = new UserProfile(501, "mouni", "vani@gmail.com", 9133557589L,  LocalDate.of(2002, 9, 05),"male", new Address());

	int profileId = 501;

	when(profileserimpl.getByProfileId(profileId)).thenReturn(userprofile);
	when(profileserimpl.addNewCustomerProfile(userprofile)).thenReturn(userprofile);
	ResponseEntity<UserProfile> addUser = profilecontroller.addNewCustomerProfile(userprofile);
	assertEquals(profileId, addUser.getBody().getProfileId());
}

@Test
public void deleteProfile() {

	userprofile = new UserProfile(24, "mounika",  "Pounikaalla141@gmail.com", 9182235379L,  LocalDate.of(2001, 03, 05),"male", new Address());
	int profileId = 24;
	profileRepo.deleteById(profileId);

}
@Test
public void getAllProfiletest() {
	List<UserProfile> users = new ArrayList<>();
	UserProfile u = new UserProfile();

	u.setProfileId(501);
	u.setFullName("mouni");
	u.setGender("male");
	u.setDateOfBirth(LocalDate.of(2002, 9, 05));
	u.setEmailId("vani@gmail.com");
	

	users.add(u);

	when( profileRepo.findAll()).thenReturn(users);
	
}
@Test
public void getByProfileId_test() {
	UserProfile u = new UserProfile();

	u.setProfileId(501);
	u.setFullName("mouni");
	u.setGender("male");
	u.setDateOfBirth(LocalDate.of(2002, 9, 05));
	u.setEmailId("vani@gmail.com");

	

	Optional<UserProfile> userprofile = Optional.of(u);
	when(profileRepo.findById(501)).thenReturn(userprofile);
	
}




}
