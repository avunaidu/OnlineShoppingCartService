package com.naidu.login.Exception;

public class AdminNotFoundException extends RuntimeException{
	
	public AdminNotFoundException(String msg){
		super(msg);
	}
}
