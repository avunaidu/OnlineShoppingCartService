package com.naidu.payment.exception;

public class PaymentNotFoundWithIdException extends Exception {
public PaymentNotFoundWithIdException(String message) {
	super(message);
}
}
