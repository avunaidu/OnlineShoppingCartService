package com.naidu.payment.entity;

public enum PaymentType {
	DEBIT_CARD,
	CREDIT_CARD,
	CASHON_DELIVERY
}
