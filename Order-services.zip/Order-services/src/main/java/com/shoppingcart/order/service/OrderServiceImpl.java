package com.shoppingcart.order.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppingcart.order.entity.Address;
import com.shoppingcart.order.entity.Orders;
import com.shoppingcart.order.exception.AddressNotFoundException;
import com.shoppingcart.order.exception.OrdersNotFoundException;
import com.shoppingcart.order.repository.AddressRepository;
import com.shoppingcart.order.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository orderrepository;

	@Autowired
	AddressRepository addressrepository;

	public List<Orders> getAllOrders() throws OrdersNotFoundException {
		
		List<Orders> findAll = orderrepository.findAll();

		if (!findAll.isEmpty()) {

			return orderrepository.findAll();
		} else {
			throw new OrdersNotFoundException("No datas found");
		}

	}

	public List<Address> getAllAddress() throws AddressNotFoundException {
		List<Address> findAll = addressrepository.findAll();

		if (!findAll.isEmpty()) {
			return addressrepository.findAll();
		} else {

			throw new AddressNotFoundException("No datas found");
		}
	}

	public Orders getOrderByOrderId(int id) throws OrdersNotFoundException {
		Optional<Orders> findById = orderrepository.findByOrderId(id);
		if (!findById.isEmpty()) {
			return findById.get();
		} else {
			throw new OrdersNotFoundException(id + " Does Not Exists");
		}
	}

	public List<Address> getOrderByCustomerId(Integer id) throws AddressNotFoundException {
		List<Address> findById= addressrepository.findByCustomerId(id);
		if (!findById.isEmpty()) {
			return addressrepository.findByCustomerId(id);
		} else {
			throw new AddressNotFoundException(id + " Does Not Exists");
		}

	}

	public List<Orders> getOrdersByAddress(int id) throws OrdersNotFoundException {
		List<Orders> findByCustomerId = orderrepository.findByCustomerId(id);
		if (!findByCustomerId.isEmpty()) {
			return orderrepository.findByCustomerId(id);
		} else {
			throw new OrdersNotFoundException(id + " Does Not Exists");
		}
	}

	@Override
	public Address storeAddress(Address address) {
		List<Address> findByCustomerId = addressrepository.findByCustomerId(address.getCustomerId());
		if (findByCustomerId.isEmpty()) {
			return addressrepository.save(address);
		} else {
			throw new AddressNotFoundException(address.getCustomerId() + " Already exists");
		}
	}

	@Override
	public Orders changeOrderStatus(String status, int id) {
		Optional<Orders> findByOrderId = orderrepository.findByOrderId(id);
		if (!findByOrderId.isEmpty()) {
			Orders order = orderrepository.findByOrderId(id).orElseThrow();
			order.setOrderStatus(status);
			return order;
		} else {
			throw new OrdersNotFoundException("Invalid Id status cannot be changed");
		}

	}

	@Override
	public String deleteOrder(int id) throws OrdersNotFoundException {
		Optional<Orders> findById = orderrepository.findById(id);
		if (findById.isPresent()) {
			orderrepository.deleteById(id);
			return "Deleted Sucessfully";

		} else {
			throw new OrdersNotFoundException(id + " Already been deleted or not been present");
		}

	}

	@Override
	public Orders placeorders(Orders order) {
		Optional<Orders> findById = orderrepository.findById(order.getOrderId());
		if (findById.isEmpty()) {
			return orderrepository.insert(order);
		} else {
			throw new OrdersNotFoundException("Order is already placed on this id");
		}
	}

}
